/**@type {HTMLCanvasElement} */
const can = document.getElementById("can");
const ctx = can.getContext("2d");

function drawOutlineRect(){

}

class Obj{
    constructor(x,y,w,h){
        let t = this;
        t.x = x;
        t.y = y;
        t.w = w;
        t.h = h;
    }
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    draw(){
        let t = this;
        ctx.fillStyle = "gray";
        ctx.fillRect(Math.floor(t.x),Math.floor(t.y),t.w,t.h);
    }
}
class Player extends Obj{
    constructor(x,y,col){
        super(x,y,10,20);
        let t = this;
        t.col = col;
    }
    col = "red";
    vx = 0;
    vy = 0;
    ay = 0;
    grounded = false;
    draw(){
        let t = this;
        ctx.fillStyle = t.col;
        ctx.fillRect(Math.floor(t.x),Math.floor(t.y),t.w,t.h);
    }
}

/**@type {Obj[]} */
let objs = [];
/**@type {Player[]} */
let ens = [];

objs.push(new Obj(0,Math.floor(can.height*0.9),can.width,Math.floor(can.height*0.2)));
objs.push(new Obj(40,Math.floor(can.height*0.8),can.width-80,Math.floor(can.height*0.2)));

let cx = can.width/2;
let cy = can.height/2;

//platforms
objs.push(new Obj(cx+30,cy,20,3));
objs.push(new Obj(cx+10,cy+30,20,3));

//players
let me = new Player(can.width/2,can.height/2,"red");
ens.push(me);

let gravity = 0.2;
let drag = 0.8;

let speed = 0.5;
let maxVel = 4;
let velTolerance = 0.05;

function update(){
    requestAnimationFrame(update);
    ctx.clearRect(0,0,can.width,can.height);

    for(let i = 0; i < objs.length; i++){
        let o = objs[i];
        o.draw();
    }
    for(let i = 0; i < ens.length; i++){
        let o = ens[i];
        o.grounded = false;
        o.vy += o.ay;
        let drag2 = 0.3;
        if(o.ay >= drag2) o.ay -= drag2;
        else if(o.ay <= -drag2) o.ay += drag2;
        else o.ay = 0;
        o.vy += gravity;
        function check(vx,vy){
            o.x += vx;
            o.y += vy;
            for(let j = 0; j < objs.length; j++){
                let o2 = objs[j];
                let tol = speed/2;
                let left = (o.x+o.w - o2.x);
                let right = (o.x - (o2.x+o2.w));
                let top = (o.y+o.h - o2.y);
                let bottom = (o.y - (o2.y+o2.h));
                if(left < tol) continue;
                if(top < tol) continue;
                if(right > tol) continue;
                if(bottom > tol) continue;

                let atop = Math.abs(top);
                let abottom = Math.abs(bottom);
                let aleft = Math.abs(left);
                let aright = Math.abs(right);
                let l = [atop,abottom,aleft,aright];
                let min = Math.min(...l);
                if(min == atop){
                    o.y = o2.y-o.h;
                    o.vy = 0;
                    o.grounded = true;
                }
                else if(min == abottom){
                    if(vy < 0){
                        o.y = o2.y+o2.h;
                        o.vy = 0;
                    }
                }
                else if(min == aleft){
                    o.x = o2.x-o.w;
                    o.vx = 0;
                }
                else if(min == aright){
                    if(vx < 0){
                        o.x = o2.x+o2.w;
                        o.vx = 0;
                    }
                }
            }
        }
        check(o.vx,0);
        check(0,o.vy);
        o.draw();
    }

    //player keybinds
    if(keys.a){
        me.vx -= (me.grounded ? speed : speed*0.3);
    }
    else if(keys.d){
        me.vx += (me.grounded ? speed : speed*0.3);
    }
    if(me.grounded) if(keys[" "]){
        me.vy -= 4;
        me.grounded = false;
    }
    if(me.vx > maxVel) me.vx = maxVel;
    else if(me.vx < -maxVel) me.vx = -maxVel;
    if(me.vy > maxVel) me.vy = maxVel;
    else if(me.vy < -maxVel) me.vy = -maxVel;
    if(me.grounded) me.vx *= drag;
    else me.vx *= 0.90;
    if(me.vx <= velTolerance && me.vx >= -velTolerance) me.vx = 0;
    if(me.vy <= velTolerance && me.vy >= -velTolerance) me.vy = 0;
}

/**@type {{[k:string]:string}} */
let keys = {};
document.addEventListener("keydown",e=>{
    let key = e.key.toLowerCase();
    keys[key] = true;
});
document.addEventListener("keyup",e=>{
    keys[e.key.toLowerCase()] = false;
});

update();