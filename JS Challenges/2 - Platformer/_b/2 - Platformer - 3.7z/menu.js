class Particle extends Obj{
    constructor(x,y,vx,vy,col){
        super(x,y,3,3);
        let t = this;
        t.vx = vx;
        t.vy = vy;
        t.col = col;
    }
    vx = 0;
    vy = 0;
    col = "";
    lifetime = 60;
    onupdate = function(){
        let p = this;
        ctx.fillStyle = p.col;
        ctx.fillRect(p.x-1,p.y-1,3,3);
    };
    isDead = false;
}

function createParticleBatch(x,y){
    for(let i = 0; i < 10; i++){
        let vx = (Math.random()-0.5)/2;
        let vy = (Math.random()-0.5)/2;
        let p = new Particle(x+vx*5,y+vy*5,vx*2,vy*2,"red");
        particles.push(p);
    }
}
function landingAnim(x,y,strength){
    return;
    let amt = 10+Math.floor(Math.random()*10);
    for(let i = 0; i < amt; i++){
        let vx = (Math.random()-0.5)/2;
        let vy = (-Math.random());
        let p = new Particle(x+vx*strength,y+vy*2,vx*strength,vy-strength/3,"gray");
        p.onupdate = function(){
            this.lifetime--;
            ctx.fillStyle = this.col;
            ctx.globalAlpha = this.lifetime/60;
            ctx.fillRect(this.x-1,this.y-1,3,3);
            this.vy += 0.2;
            ctx.globalAlpha = 1;
        };
        particles.push(p);
    }
}
function jumpAnim(x,y){
    let amt = 5+Math.floor(Math.random()*2);
    for(let i = 0; i < amt; i++){
        let vx = (Math.random()-0.5)/2;
        let vy = (-Math.random()/4);
        let p = new Particle(x+vx*20,y+vy*25,vx,vy/4,"lightgray");
        p.onupdate = function(){
            this.vx += (Math.random()-0.5)/20;
            this.vy += (Math.random()-0.5)/20;
            this.vy += 0.01;
            this.lifetime--;
            ctx.globalAlpha = this.lifetime/60;
            ctx.beginPath();
            ctx.arc(this.x,this.y,8,0,Math.PI*2);
            ctx.fillStyle = this.col;
            ctx.fill();
            ctx.globalAlpha = 1;
        };
        particles.push(p);
    }
}